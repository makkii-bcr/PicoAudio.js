// Initialize around AudioAPI
var pAudio = new PicoAudio();
pAudio.init();
if(pAudio.settings.isWebMIDI) pAudio.startWebMIDI();

// Display Skip-Ratio
var canvasRatio = 20;
// Note Height
var canvasNoteHeight = 4;
// Pianoroll bottom margin
var canvasBottomMargin = 75;
// Display FPS
var fps = 0;
// isBlackMode
var isBlackMode = false;
// isDisplayNice
var isDisplayNice = 1;
// isPlayerCard
var isPlayerCard = true;
// isRetroMode
var isRetroMode = false;

// Initialize around Drawing
var canvas = document.getElementsByTagName("canvas")[0];
canvas.width = canvas.offsetWidth;
canvas.height = canvas.offsetHeight;
canvasBottomMargin = (canvas.offsetHeight-384)/2 + 75;
window.addEventListener("resize", function(){
	if(canvas.width != canvas.offsetWidth) canvas.width = canvas.offsetWidth;
});

//---------
document.getElementById("titlelink").href = "http://picotune.me/"+location.search;

//------------//
function setSong(file){
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			var info = JSON.parse(this.response);
			currentLoadFile = info.file;
			favoriteList = JSON.parse("["+info.favorite+"]");
			// Set settings
			initChannels();
			if(info.settings)
				pAudio.channels = JSON.parse(info.settings);
			// LoadMIDI
			loadUploadedFile(info.file);
		}
	}
	xhr.open("GET", "./cmd/GetSong.php?file="+file);
	xhr.responseType = "text";
	xhr.send(null);
}

function initChannels(){
	for(i in pAudio.channels)
		pAudio.channels[i] = [0,0,1];
}