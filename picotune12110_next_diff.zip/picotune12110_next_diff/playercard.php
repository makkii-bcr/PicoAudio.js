

<!DOCTYPE html>
<html>
<head>
<title>Picotune</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="shortcut icon" href="./img/favicon.png?1172">
<meta name="twitter:card" content="player">
<meta name="twitter:title" content="Picotune">
<meta name="twitter:image" content="https://r6.quicca.com/~cagpie/pt/Picotune_card.png?24">
<meta name="twitter:player" content="https://r6.quicca.com/~cagpie/pt/playercard.php?QHYWJGRC">
<meta name="twitter:player:height" content="412">
<meta name="twitter:player:width" content="412">
<meta name="twitter:url" content="https://picotune.me/?QHYWJGRC">
<link href="./index.css?1211" rel="stylesheet" type="text/css">
<link href="./playercard.css?1211" rel="stylesheet" type="text/css">
<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
	ga('create', 'UA-90242923-1', 'auto');
	ga('send', 'pageview');
</script>
</head>
<body>
	<div id="header">
		<div id="headerContent">
			<div class="hContentLogo">
				<a href="http://picotune.me/" target="_blank" id="titlelink"><img src="./img/logo.png" id="header_logo"></a>
			</div>
			<div class="hContentMenu">
			</div>
		</div>
	</div>
	<div id="content">
		<div id="left">
			<div id="playSpace">
				<div id="display"><canvas width="600" height="384"></canvas></div>
				<div id="states">
					<div class="stateBlock">
						<dummy></dummy>
					</div>
					<div class="stateBlock stateBlockCenter">
						<input type="button" id="actionPre"><input type="button" id="actionPlay"></span><input type="button" id="settingNiceMode">
					</div>
					<div class="stateBlock">
						<dummy></dummy>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
<script src="./PicoAudio.min.js?1211"></script>
<script src="./playercard.js?1211"></script>
<script src="./main.js?1211"></script>
</html>