// Initialize around AudioAPI
var pAudio = new PicoAudio();
pAudio.init();
if(pAudio.settings.isWebMIDI) pAudio.startWebMIDI();

// Save data version check
var saveDataVersion = parseInt(localStorage.getItem("saveDataVersion"));
// Display Skip-Ratio
var canvasRatio = parseInt(localStorage.getItem("canvasRatio"));
if(isNaN(canvasRatio)) canvasRatio=20;
if(canvasRatio<1) canvasRatio=1;
if(canvasRatio>99) canvasRatio=99;
localStorage.setItem("canvasRatio", canvasRatio);
document.getElementById("settingRatio").value = canvasRatio;
// Note Height
var canvasNoteHeight = parseInt(localStorage.getItem("canvasNoteHeight"));
if(isNaN(canvasNoteHeight)) canvasNoteHeight=4;
if(canvasNoteHeight<1) canvasNoteHeight=1;
if(canvasNoteHeight>9) canvasNoteHeight=9;
localStorage.setItem("canvasNoteHeight", canvasNoteHeight);
document.getElementById("settingNoteHeight").value = canvasNoteHeight;
// Pianoroll bottom margin
var canvasBottomMargin = parseInt(localStorage.getItem("canvasBottomMargin"));
if(isNaN(canvasBottomMargin)) canvasBottomMargin=75;
if(canvasBottomMargin<-99) canvasBottomMargin=-99;
if(canvasBottomMargin>999) canvasBottomMargin=999;
localStorage.setItem("canvasBottomMargin", canvasBottomMargin);
document.getElementById("settingBottomMargin").value = canvasBottomMargin;
// Display FPS
var fps = parseInt(localStorage.getItem("canvasFPS"));
if(isNaN(fps) || saveDataVersion==null || saveDataVersion<124) fps=0;
if(fps<0) fps=0;
if(fps>999) fps=999;
localStorage.setItem("canvasFPS", fps);
document.getElementById("settingFPS").value = fps;
// isReverb
var isReverb = parseInt(localStorage.getItem("isReverb"));
if(isNaN(isReverb) || saveDataVersion==null) {
	isReverb = isDefaultReverb();
	localStorage.setItem("isReverb", isReverb ? "1" : "0");
}
document.getElementById("settingReverb").checked = isReverb;
pAudio.settings.isReverb = isReverb;
// isBlackMode
if(!localStorage.getItem("isBlackMode")) localStorage.setItem("isBlackMode", "0");
var isBlackMode = parseInt(localStorage.getItem("isBlackMode"));
document.getElementById("settingBlackMode").checked = isBlackMode;
// isWebMIDI
if(!localStorage.getItem("isWebMIDI")) localStorage.setItem("isWebMIDI", "0");
var isWebMIDI = parseInt(localStorage.getItem("isWebMIDI"));
document.getElementById("settingWebMIDIMode").checked = isWebMIDI;
pAudio.settings.isWebMIDI = isWebMIDI;
if(isWebMIDI){
	pAudio.startWebMIDI();
	document.getElementById("webmidiInfo").style.display = "block";
	document.getElementById("midioutSelect").onchange = function(e){
		pAudio.settings.WebMIDIPortOutput = pAudio.settings.WebMIDIPortOutputs.get(e.target.value);
	}
	setTimeout(function(){
		pAudio.settings.WebMIDIPortOutputs.forEach(function(output){
			console.log(output.name);
			createElement("option", {
				appendTo: document.getElementById("midioutSelect"),
				value: output.id,
				innerText: output.name
			});
		});
	}, 1000);
}
// isRetroMode
if(!localStorage.getItem("isRetroMode")) localStorage.setItem("isRetroMode", "0");
if(!localStorage.getItem("retroModePoly")) localStorage.setItem("retroModePoly", "3");
if(!localStorage.getItem("retroModePercPoly")) localStorage.setItem("retroModePercPoly", "1");
var isRetroMode = parseInt(localStorage.getItem("isRetroMode"));
var retroModePoly = parseInt(localStorage.getItem("retroModePoly"));
var retroModePercPoly = parseInt(localStorage.getItem("retroModePercPoly"));
if(isNaN(retroModePoly)) retroModePoly=3;
if(retroModePoly<0) retroModePoly=0;
if(isNaN(retroModePercPoly)) retroModePercPoly=1;
if(retroModePercPoly<0) retroModePercPoly=0;
document.getElementById("settingRetroMode").checked = isRetroMode;
document.getElementById("settingRetroModePoly").value = retroModePoly;
document.getElementById("settingRetroModePercPoly").value = retroModePercPoly;
if(isRetroMode){
	pAudio.settings.maxPoly = retroModePoly;
	pAudio.settings.maxPercPoly = retroModePercPoly;
}
// isDisplayNice
if(!localStorage.getItem("isDisplayNice")) localStorage.setItem("isDisplayNice", "1");
var isDisplayNice = parseInt(localStorage.getItem("isDisplayNice"));
// favorite songs
if(!localStorage.getItem("favoriteSongs")) localStorage.setItem("favoriteSongs", "{}");
var favoriteSongs = JSON.parse(localStorage.getItem("favoriteSongs"));
// isPlayerCard
var isPlayerCard = false;
// Local storage save data version
localStorage.setItem("saveDataVersion", "12100"); // v1.2.10.0


// Initialize around Drawing
var canvas = document.getElementsByTagName("canvas")[0];
canvas.width = canvas.offsetWidth;
window.addEventListener("resize", function(){
	if(canvas.width != canvas.offsetWidth) canvas.width = canvas.offsetWidth;
	if(!pAudio.states.isPlaying){
		var context = canvas.getContext('2d');
		if(!isFirst || (pAudio.hashedDataList instanceof Array && pAudio.hashedDataList.length>0)){
			draw(Math.floor(pAudio.getTiming(pAudio.states.stopTime-pAudio.states.startTime)/canvasRatio - canvas.width/2));
			context.globalAlpha = 0.5;
		} else {
			context.clearRect(0, 0, canvas.width, canvas.height);
		}
		context.drawImage(stop_icon, Math.floor((canvas.width-376)/2), Math.floor((canvas.height-376)/2));
		context.globalAlpha = 1;
	}
});

// Initialize Loading Local MIDI File
var inputFile = document.getElementById("midifile");

// Initialize around Balloon and Windows
var menuLoadButton = document.getElementById("menuLoadButton");
function displayLocalList(){
	document.getElementById('right_all').style.display = 'none';
	document.getElementById('right_favorite').style.display = 'none';
	document.getElementById('right_user').style.display = 'none';
	document.getElementById('right_local').style.display = 'block';
	currentView = 3;
}

//
var currentView = 0;

//---------------------------------//
//---- Load Uploaded Song List ----//
//---------------------------------//
(function(){
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			// Pickups
			var list = document.getElementById("right_all");
			var json = JSON.parse(this.response);
			createElement("div", {
				appendTo: list,
				className: "right_list_head",
				textContent: "- Pickup! -"
			});
			var count = 0;
			json.forEach(function(info, idx){
				if(count==3 || info.file=="QHYWJGRC.mid") return;
				if(displayListCell(info, list)) count++;
			});
			// List
			(function(){
				var xhr = new XMLHttpRequest();
				xhr.onreadystatechange = function(){
					if(this.readyState==4 && this.status==200){
						var list = document.getElementById("right_all");
						var json = JSON.parse(this.response);
						createElement("div", {
							appendTo: list,
							className: "right_list_head",
							textContent: "- Latest -"
						});
						json.forEach(function(info, idx){
							if (latestSongList.indexOf(info.file)!=-1) return;
							displayListCell(info, list);
							if (info.file) latestSongList.push(info.file);
						});
					}
				}
				xhr.open("GET", "./cmd/GetList.php");
				xhr.responseType = "text";
				xhr.send(null);
			})();
		}
	}
	xhr.open("GET", "./cmd/GetPickup.php");
	xhr.responseType = "text";
	xhr.send(null);
})();


//--------------------------------------------//
//---- Additional Load Uploaded MIDI List ----//
//--------------------------------------------//
var isLoadingList = false;
var isListEnd = false;
document.getElementById("right").addEventListener("scroll", function(e){
	if(e.target.scrollHeight-e.target.scrollTop < document.getElementById("right").offsetHeight*2){
		loadSongList();
	}
});
function loadSongList() {
	if(document.getElementById("right_all").style.display != "none"
		&& !isLoadingList
		&& !isListEnd
	){
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function(){
			if(this.readyState==4 && this.status==200){
				var json = JSON.parse(this.response);
				var isAddSong = false;
				var list = document.getElementById("right_all");
				json.forEach(function(info, idx){
					if (latestSongList.indexOf(info.file)!=-1) return;
					displayListCell(info, list);
					if (info.file) {
						latestSongList.push(info.file);
						isAddSong = true;
					}
				});
				if(!isAddSong){
					isListEnd = true;
					latestSongList.push(null); // song list eof
					return;
				}
				isLoadingList = false;
			}
		}
		xhr.open("GET", "./cmd/GetList.php?i="+(document.getElementById("right_all").childElementCount-6));
		xhr.responseType = "text";
		xhr.send(null);
		isLoadingList = true;
	}
}

//---------------------------------//
//---- Load Favorite Song List ----//
//---------------------------------//
setTimeout(function(){
	Object.keys(favoriteSongs).reverse().forEach(function(song) {
		if(favoriteSongs[song].fav < 1) return;
		displayListCell(favoriteSongs[song], document.getElementById("right_favorite"), true);
		favoriteSongList.push(favoriteSongs[song].file);
	});
}, 1000);

//------------------------------//
//---- Load Local Song List ----//
//------------------------------//
var localSongList = localSongList || [];
var localSongRandomList = localSongRandomList || [];
var db;
var req = window.indexedDB.open('pt_local_db', 4);
// new or up
req.onupgradeneeded = function(e){
	var db = e.target.result;
	e.target.transaction.onerror = function(err) { console.log(err) }
	if (db.objectStoreNames.contains('local')) db.deleteObjectStore('local');
	var store = db.createObjectStore('local', {autoIncrement:true});
};
// Get List
req.onsuccess = function(e){
	db = (e.target) ? e.target.result : e.result;
	var tx = db.transaction(["local"],"readwrite");
	var store = tx.objectStore("local");
	// keyPathに対して検索をかける範囲を取得
	var range = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(range, 'prev');
	// カーソルリクエストが成功したら...
	cursorRequest.onsuccess = function(e){
		var result = e.target.result;
		if (!result) return;
		localSongList.push(result.value.title);
		localSongRandomList.splice(Math.floor(Math.random()*(localSongRandomList.length+1)), 0, result.value.title);
		displayListCell({title:result.value.title}, document.getElementById("right_local"), true, true);
		// カーソルを一個ずらす
		result.continue();
	}
	// カーソルリクエストが失敗したら...
	cursorRequest.onerror = function(err){console.log(err)};
};

//--------------------------------//
//---- Display User MIDI List ----//
//--------------------------------//
function displayUserMidiList(user, callback){
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			var list = document.getElementById("right_user");
			var json = JSON.parse(this.response);
			if(json.length<=1) return;
			// callback
			if (callback) {
				callback(json);
			}
			// clear
			[].slice.call(list.childNodes).forEach(function(node){
				list.removeChild(node);
			});
			// url
			//location.hash = "@"+json[0].user;
			history.replaceState('','','?'+"@"+json[0].user);
			// back & title
			var userTop = createElement("div",{
				appendTo: list,
				className: "head"
			});
			createElement("span", {
				appendTo: userTop,
				textContent: "←",
				style: {
					cursor:"pointer"
				},
				onclick: function(){
					list.style.display = "none";
					document.getElementById("right_all").style.display = "block";
				}
			});
			createElement("span", {
				appendTo: userTop,
				textContent: json[0].user,
			});
			json.forEach(function(info, idx){
				displayListCell(info, list);
				tabSongList.push(info.file);
			});
			list.style.display = "block";
			document.getElementById("right_all").style.display = "none";
			document.getElementById("right_favorite").style.display = "none";
			currentView = 2;
		}
	}
	xhr.open("GET", "./cmd/GetUser.php?u="+user);
	xhr.responseType = "text";
	xhr.send(null);
}


//---------------------------//
//---- Display List Cell ----//
//---------------------------//
function displayListCell(info, target, isDeleteButton, isLocal, insertBeforeElem){
	if(!info.file && !isLocal) return false;
	var dummyAppendToObj = {appendChild:function(){}};
	var dummyInsertBeforeToAry = [{insertBefore:function(){}}, null];
	if(isDeleteButton){
		var target2 = target;
		target = createElement("div", {
			appendTo: !insertBeforeElem ? target2 : dummyAppendToObj,
			insertBeforeTo: insertBeforeElem ? [target2, insertBeforeElem] : dummyInsertBeforeToAry,
			style: {
				display: "flex",
				justifyContent: "space-between"
			}
		});
	}
	if(!isLocal){
		var d = createElement("div", {
			appendTo: target,
			innerHTML: info.user+" - <spam style='font-size:smaller'>"+info.date +"</spam><br><spam style='font-weight:bolder'>"+info.title+"</spam>",
			className: "list",
			onclick: function(){
				setSong(info.file);
			}
		});
	} else {
		var d = createElement("div", {
			appendTo: !insertBeforeElem||isDeleteButton ? target : dummyAppendToObj,
			insertBeforeTo: insertBeforeElem&&!isDeleteButton ? [target, insertBeforeElem] : dummyInsertBeforeToAry,
			innerHTML: "<spam style='font-weight:bolder'>"+info.title.split(/\\|\//).pop()+"</spam>",
			className: "list",
			onclick: function() {
				setLocalSong(info);
			}
		});
	}
	if(isDeleteButton){
		createElement("div", {
			appendTo: target,
			textContent: "×",
			style : {
				width: "10px",
			},
			onclick: function(){
				if(!isLocal){
					favoriteSongList.splice(favoriteSongList.indexOf(info.file),1);
					favoriteSongs[info.file].fav = 0;
					localStorage.setItem("favoriteSongs", JSON.stringify(favoriteSongs));
				} else {
					var tx = db.transaction(["local"],"readwrite");
					var store = tx.objectStore("local");
					var range = IDBKeyRange.lowerBound(0);
					var cursorRequest = store.openCursor(range, 'prev');
					cursorRequest.onsuccess = function(e){
						var result = e.target.result;
						if (!result) return;
						if(result.value.title == info.title){
							result.delete();
							localSongList.splice(localSongList.indexOf(info.title), 1); // delete
							localSongRandomList.splice(localSongRandomList.indexOf(info.title), 1); // delete
						}
						result.continue();
					}
				}
				this.parentNode.remove();
			}
		});
	}
	return d;
}
function setLocalSong(info){
	var storageName = "songSetting_"+info.title;
	if(localStorage.getItem(storageName))
		pAudio.channels = JSON.parse(localStorage.getItem(storageName));
	else
		initChannels();
	favoriteList = [];

	var tx = db.transaction(["local"],"readwrite");
	var store = tx.objectStore("local");
	var cursorRequest = store.openCursor(IDBKeyRange.lowerBound(0));
	cursorRequest.onsuccess = function(e){
		var result = e.target.result;
		if (!result) return;
		if(result.value.title == info.title){
			currentLoadFile = info.title;
			loadFile(result.value.file);
			return;
		}
		result.continue();
	}
	document.getElementById("info_message").style.display = "none";
	document.getElementById("info_footer").style.display = "none";
	document.getElementById("info_content").style.display = "none";
	document.getElementById("local_info_content").style.display = "block";
	document.getElementById("local_info_title").textContent =
		info.title.match(/https?:\/\/.+/) ? info.title : info.title.split(/\\|\//).pop(); // URLはフルパスで表示
	if(!pAudio.settings.isWebMIDI){
		var sS = document.getElementById("editSondSettings");
		sS = sS.parentNode.removeChild(sS);
		document.getElementById("info").appendChild(sS);
		initSongSetting(function(){
			localStorage.setItem(storageName, JSON.stringify(pAudio.channels));
		});
	}
}

//-----------------//
//---- setSong ----//
//-----------------//
var isSetSong = false;
function setSong(file, isBack){
	if(isSetSong) return;
	isSetSong = true;
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			var list = document.getElementById("right_all");
			var info = JSON.parse(this.response);
			currentLoadFile = info.file;
			if(!isBack) currentPlayListIndex++;
			playList[currentPlayListIndex] = currentLoadFile;
			favoriteList = JSON.parse("["+info.favorite+"]");
			document.getElementById("info_message").style.display = "none";
			document.getElementById("info_footer").style.display = "block";
			document.getElementById("info_content").style.display = "block";
			document.getElementById("local_info_content").style.display = "none";
			//location.hash = info.file.slice(0,8);
			history.replaceState('','','?'+info.file.slice(0,8));
			document.getElementById("info_title").textContent = info.title;
			document.getElementById("info_user").innerHTML = info.twitter_id ? "<a href='https://twitter.com/"+info.twitter_id+"'>"+info.user+"</a>" : info.user;
			document.getElementById("info_description").textContent = info.description;
			if(info.url.split(":")[0]=="http" || info.url.split(":")[0]=="https")
				document.getElementById("info_url").innerHTML = "<a href='"+info.url+"'>"+info.url+"</a>";
			else document.getElementById("info_url").innerHTML = "";

			document.getElementById("info_date").textContent = info.date;
			document.getElementById("info_license").href = "https://creativecommons.org/licenses/" + ["by", "by-nd", "by-sa", "by-nc", "by-nc-nd", "by-nc-sa"][info.lisence] + "/4.0/";
			document.getElementById("info_license_img").src = "https://licensebuttons.net/l/" + ["by", "by-nd", "by-sa", "by-nc", "by-nc-nd", "by-nc-sa"][info.lisence] + "/4.0/88x31.png";
			//
			document.getElementById("info_listlink").onclick = function(){ displayUserMidiList(info.user) };
			// Set settings
			initChannels();
			if(info.settings)
				pAudio.channels = JSON.parse(info.settings);
			// Tweet
			document.getElementById("info_tweet").innerHTML =
				'<iframe id="twitter-widget-1" scrolling="no" allowtransparency="true" class="twitter-share-button twitter-share-button-rendered twitter-tweet-button" style="position: static; visibility: visible; width: 68px; height: 20px;" title="Twitter Tweet Button" src="https://platform.twitter.com/widgets/tweet_button.c4fd2bd4aa9a68a5c8431a3d60ef56ae.ja.html#dnt=false&amp;hashtags=Picotune&amp;id=twitter-widget-1&amp;lang=ja&amp;original_referer=https%3A%2F%2Fabout.twitter.com%2Fja%2Fresources%2Fbuttons%23tweet&amp;size=m&amp;text='+info.title+" ("+info.user+")"+'&amp;time=1484452882908&amp;type=share&amp;url=http%3A%2F%2Fpicotune.me%2F?'+info.file.slice(0,8)+'" data-url="http://picotune.me/?'+info.file.slice(0,8)+'" frameborder="0"></iframe>';
			document.getElementById("info_midi").href = "./midifiles/"+info.file;
			// Delete
			document.getElementById("info_delete").onclick = function(){
				var ps = prompt("楽曲を削除する場合はパスワードを入力してください");
				if(!ps) return;
				location.href = "http://picotune.me/cmd/Delete.php?file="+info.file+"&pass="+ps;
			}
			// Edit
			document.getElementById("info_edit").onclick = function(){
				document.getElementById("editWindow").style.display = "block";
			}
			document.getElementById("editFile").value = info.file;
			document.getElementById("editTitle").value = info.title;
			document.getElementById("editUser").value = info.user;
			document.getElementById("editDescription").value = info.description;
			document.getElementById("editUrl").value = info.url;
			document.getElementById("editTwitter_id").value = info.twitter_id;
			var sS = document.getElementById("editSondSettings");
			sS = sS.parentNode.removeChild(sS);
			document.getElementById("editWindowSongSettings").appendChild(sS);
			initSongSetting();
			// Display
			document.getElementById("info_content").style.display = "block";
			// LoadMIDI
			loadUploadedFile(info.file);
		}
		if(this.readyState==4){
			isSetSong = false;
		}
	}
	xhr.open("GET", "./cmd/GetSong.php?file="+file);
	xhr.responseType = "text";
	xhr.send(null);
}

//--------------//
//---- Edit ----//
//--------------//
function initSongSetting(changeTrigger){
	if(!changeTrigger) changeTrigger = function(){};
	var songSettingTag = document.getElementById("editSondSettings");
	songSettingTag.innerHTML = "";
	for(var i=0; i<16; i++){
		var div = createElement("div", {
			textContent: "Channel"+(i+1)+":",
			style: {
				color: ChannelColor[i]
			},
			appendTo: songSettingTag
		});
		var selTone = createElement("select", {
			name: "tone"+i,
			onchange: function(){ pAudio.channels[this.name.slice(4)][0] = this.selectedIndex; changeTrigger(); },
			appendTo: div
		});
		["0:Preset","1:Sine","2:Square","3:Sawtooth","4:Triangle"].forEach(function(key, idx){
			var e = createElement("option", {
				value: idx,
				textContent: key,
				appendTo: selTone
			});
			if(pAudio.channels[i][0]==idx) e.selected=true;
		});
		var selAtte = createElement("select", {
			name: "attenuation"+i,
			onchange: function(){ pAudio.channels[this.name.slice(11)][1] = this.selectedIndex; changeTrigger(); },
			appendTo: div
		});
		["0:Preset","1:減衰なし","2:ピッチカート系減衰","3:ピアノ系減衰","4:ナイロンギター系減衰","5:エレピ系減衰"].forEach(function(key, idx){
			var e = createElement("option", {
				value: idx,
				textContent: key,
				appendTo: selAtte
			});
			if(pAudio.channels[i][1]==idx) e.selected=true;
		});
		var selVol = createElement("select", {
			name: "volume"+i,
			onchange: function(){ pAudio.channels[this.name.slice(6)][2] = this.options[this.selectedIndex].value; changeTrigger(); },
			appendTo: div
		});
		for(var m=0; m<21; m++){
			var e = createElement("option", {
				value: m/10,
				textContent: "Volume * "+m/10,
				appendTo: selVol
			});
			if(pAudio.channels[i][2]==m/10) e.selected=true;
		}
	}
}

//----------------------//
//---- Save Setting ----//
//----------------------//
function saveSetting(){
	localStorage.setItem("saveDataVersion", "12100"); // v1.2.10.0
	localStorage.setItem("canvasRatio", parseInt(document.getElementById("settingRatio").value));
	localStorage.setItem("canvasNoteHeight", parseInt(document.getElementById("settingNoteHeight").value));
	localStorage.setItem("canvasBottomMargin", parseInt(document.getElementById("settingBottomMargin").value));
	localStorage.setItem("canvasFPS", parseInt(document.getElementById("settingFPS").value));
	localStorage.setItem("isReverb", document.getElementById("settingReverb").checked ? 1 : 0);
	localStorage.setItem("isBlackMode", document.getElementById("settingBlackMode").checked ? 1 : 0);
	localStorage.setItem("isWebMIDI", document.getElementById("settingWebMIDIMode").checked ? 1 : 0);
	localStorage.setItem("isRetroMode", document.getElementById("settingRetroMode").checked ? 1 : 0);
	localStorage.setItem("retroModePoly", parseInt(document.getElementById("settingRetroModePoly").value));
	localStorage.setItem("retroModePercPoly", parseInt(document.getElementById("settingRetroModePercPoly").value));
	window.location.reload();
}

//------------------------------//
//---- Load Local MIDI File ----//
//------------------------------//
inputFile.onchange = function(){
	var file = inputFile.files[0];
	var reader = new FileReader();
	currentLoadFile = null;
	reader.onload = function(e){
		var file = reader.result;
		var storageName = "songSetting_"+document.getElementById("midifile").value;
		if(localStorage.getItem(storageName))
			pAudio.channels = JSON.parse(localStorage.getItem(storageName));
		else
			initChannels();
		favoriteList = [];
		//loadFile(file);
		document.getElementById("info_message").style.display = "none";
		document.getElementById("info_footer").style.display = "none";
		document.getElementById("info_content").style.display = "none";
		document.getElementById("local_info_content").style.display = "none";
		if(!pAudio.settings.isWebMIDI){
			var sS = document.getElementById("editSondSettings");
			sS = sS.parentNode.removeChild(sS);
			document.getElementById("info").appendChild(sS);
			initSongSetting(function(){
				localStorage.setItem(storageName, JSON.stringify(pAudio.channels));
			});
		}

		var tx = db.transaction(["local"],"readwrite");
		var store = tx.objectStore("local");
		var cursorRequest = store.openCursor(IDBKeyRange.lowerBound(0));
		var flag = true;
		cursorRequest.onsuccess = function(e){
			var result = e.target.result;
			if (!result){
				if(flag){
					var midiFilePath = document.getElementById("midifile").value;
					var req = store.put({title: midiFilePath, file: file});
					localSongList.unshift(midiFilePath);
					localSongRandomList.splice(Math.floor(Math.random()*(localSongRandomList.length+1)), 0, midiFilePath);
					displayListCell({title: midiFilePath}, document.getElementById("right_local"), true, true
						, document.getElementById("right_local").children[2]);
					currentLoadFile = midiFilePath;

					req.onsuccess = function(){
						loadFile(file);
					}
					req.onerror = function(){
						loadFile(file);
					}
				} else {
					loadFile(file);
				}

				return;
			}
			if(result.value.title == document.getElementById("midifile").value) flag = false;
			result.continue();
		}
	};
	reader.readAsArrayBuffer(file);
}

//-------------------------------//
//---- Load Global MIDI File ----//
//-------------------------------//
function loadGlobalFile(url){
	if(!url) url = document.getElementById("midiurl").value;
	currentLoadFile = null;
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			initChannels();
			favoriteList = [];
			var file = this.response;

			var tx = db.transaction(["local"],"readwrite");
			var store = tx.objectStore("local");
			var cursorRequest = store.openCursor(IDBKeyRange.lowerBound(0));
			var flag = true;
			cursorRequest.onsuccess = function(e){
				var result = e.target.result;
				if (!result){
					if(flag){
						var midiFilePath = document.getElementById("midiurl").value;
						var req = store.put({title: midiFilePath, file: file});
						localSongList.unshift(midiFilePath);
						localSongRandomList.splice(Math.floor(Math.random()*(localSongRandomList.length+1)), 0, midiFilePath);
						displayListCell({title: midiFilePath}, document.getElementById("right_local"), true, true
							, document.getElementById("right_local").children[2]);
						currentLoadFile = midiFilePath;
						req.onsuccess = function(){loadFile(file);}
						req.onerror = function(){loadFile(file);}
					} else {
						loadFile(file);
					}
					return;
				}
				if(result.value.title == document.getElementById("midiurl").value) flag = false;
				result.continue();
			}
		}
	}
	xhr.open("POST", "./cmd/LoadMIDI.php");
	xhr.responseType = "arraybuffer";
	xhr.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
	xhr.send("url="+url);
	history.pushState('','','?url='+url);
}

function isArmv7l(){ // Raspberry Pi
	var u = navigator.userAgent.toLowerCase();
	return u.indexOf("armv7l") != -1;
}

function isDefaultReverb(){
	if (this.isArmv7l()) return false;
	return true;
}

// Wrap createElement Function
function createElement(tagName, options){
	var options = options;
	var tag = document.createElement(tagName);
	Object.keys(options).forEach(function(key){
		if(key=='appendTo'){
			options[key].appendChild(tag);
			return;
		} else if(key=='insertBeforeTo'){
			options[key][0].insertBefore(tag, options[key][1]);
			return;
		} else if(key=='style'){
			Object.keys(options[key]).forEach(function(keyStyle){
				tag.style[keyStyle] = options[key][keyStyle];
			});
			return;
		}
		tag[key] = options[key];
	});
	return tag;
}

function initChannels(){
	for(i in pAudio.channels)
		pAudio.channels[i] = [0,0,1];
}