■変更点
※diff.htmlを開いて、画面の左側が変更前、右側が変更後

●PicoAudio.js
・PicoAudio.jsからPicoAudio.min.jsに変更（ソースマップ付き）
  ⇒ソースマップがいらない場合は、Githubの方のPicoAudio.jsやmin.jsを使ってください。


●index.css
・#infoにiOSでスクロールが滑らかになるよう-webkit-overflow-scrolling: touch;を追加

●index.html
・PicoAudio.jsからPicoAudio.min.jsに変更
・キャッシュを更新させるため、「?」後の値を変更

●index.js
・「pAudio.init();」を復活
  ⇒PicoAudioの初期化処理をページロード時に行うことで、
    ページロード初回の再生ボタン押下時の処理落ちを軽減。
    Chromeで音が鳴るよう、click時にAudioContext生成していましたが、
    別な方法としてAudioContextをページロード時に生成し、
    click時にAudioContext.resume()を呼ぶようにしました。
    （consoleに警告は出るようになってしまいますが音は鳴ります。処理落ち軽減を優先してみました）

・localStorage関連の処理を少し変更
  ・saveDataVersionの値を変更
  ・AndroidでもリバーブをデフォルトONに変更
    （最近のスマホスペック向上のためリバーブONでもほとんどの端末で大丈夫だろうと判断しました）

・スーパーリロード時、曲リストが出ないバグを修正
  ⇒index.jsとmain.jsの読み込み順番の関係で、
    index.js側で変数・関数が未定義エラーが起きていました。
    playercard.js側でもバグらないようにするため、
    雑な対応ですが、index.jsとmain.jsに以下を二重定義しました。
    ・createElement()
    ・initChannels()
    ・localSongList
    ・localSongRandomList

●main.js
・debug表示関連の処理を変更
・「pAudio.init();」を削除
  ⇒PicoAudioの初期化処理をクリック前に行うよう変更したため。
・曲の終了時に、リストの最後を超えたとき、処理しないよう修正


Twitterカード側

●playercard.js
・main.jsのinitChannels()を定義（js読み込み順番によるエラー防止のため）

●playercard.php
・PicoAudio.jsからPicoAudio.min.jsに変更
・キャッシュを更新させるため、「?」後の値を変更
