//------------------------//
//---- Initialization ----//
//------------------------//

// Root Note Names
var CHORDS = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
// C-ChordNames
var C_CHORDS =	{
	"C":		[0,4,7],		"C7":		[0,4,7,10],
	"Cm":		[0,3,7],		"Cm7":		[0,3,7,10],
	"CM7":		[0,4,7,11],		"CmM7":		[0,3,7,11],
	"Csus4":	[0,5,7],		"C7sus4":	[0,5,7,10],
	"Cdim":		[0,3,6,9],		"Cm7-5":	[0,3,6,10],
	"Caug":		[0,4,8],		"Cadd9":	[0,2,7],
	"C6":		[0,4,7,9],		"Cm6":		[0,3,7,9]
};
// Color of Channel
var ChannelColor = [
	"#f66", "#fa6", "#f6f", "#6f6",
	"#6af", "#66f", "#f22", "#fa2",
	"#f2f", "#666", "#2f2", "#2af",
	"#22f", "#a00", "#060", "#006",
	"#000", "#000", "#000", "#000",
	"#000", "#000", "#000", "#000"
];

// Initialize Playing Data
var data = null;
var otherOption = [];
initChannels();

// Initialize around Drawing
var stop_icon = new Image();
stop_icon.src = "./img/Picotune_icon.png";
stop_icon.onload = function(){ canvas.getContext('2d').drawImage(stop_icon, Math.floor((canvas.width-376)/2), Math.floor((canvas.height-376)/2)); }
var logo_icon = new Image();
logo_icon.src = "./img/logo2.png";
var backCanvases = [];
var backPianoRoll = createElement('canvas', { width: canvas.width, height: canvas.height });
	backPianoRoll.getContext('2d').fillStyle = "#f0f0f0";
	for(var i=0; i<128; i++)
		if([1,3,6,8,10].some(function(k){return i%12==k}))
			backPianoRoll.getContext('2d').fillRect(0, 384-i*canvasNoteHeight+canvasBottomMargin-canvasNoteHeight, canvas.width, canvasNoteHeight);

// favorite songs
if(!localStorage.getItem("favoriteSongs")) localStorage.setItem("favoriteSongs", "{}");
var favoriteSongs = JSON.parse(localStorage.getItem("favoriteSongs"));

// variables
var polyphonyCnt = 0;
var currentPlayingNotes = [];
var isFirst = true;
var currentLoadFile = null;
var isNiceMode = false;
var favoriteList = [];

//todo

var playList = [];
var currentPlayListIndex = -1;

// for stream playing
var latestSongList = [];
var favoriteSongList = [];
var tabSongList = [];
var localSongList = localSongList || [];
var localSongRandomList = localSongRandomList || [];


// URL-Load user
if(location.hash){
	if(location.hash.substr(0,2)=="#@")
		displayUserMidiList(location.hash.substr(2));
	else if(location.hash.length==9)
		setSong(location.hash.substr(1)+".mid");
}
if(location.search){
	if(location.search.substr(0,2)=="?@")
		displayUserMidiList(location.search.substr(2), function(songs){
			setSong(songs[0].file);
		});
	else
		setSong(location.search.substr(1,8)+".mid");
}


//---------------------------------//
//---- Load Uploaded MIDI File ----//
//---------------------------------//
function loadUploadedFile(id){
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			loadFile(this.response);
		}
	}
	xhr.open("GET", "./midifiles/"+id);
	xhr.responseType = "arraybuffer";
	xhr.send(null);
}

//------------------------//
//---- Load MIDI File ----//
//------------------------//
function loadFile(file){
	if(pAudio.states.isPlaying) pAudio.stop();
	if(pAudio.debug){
		var syoriTimeS = performance.now();
	}
	// load and init AudioData
	var array = new Uint8Array(file);
	data = pAudio.parseSMF(array);
	if(typeof data == "string"){
		console.log(data);
		return;
	}
	if(pAudio.debug){
		var syoriTimeS2 = performance.now();
	}
	// Pre Draw Piano Roll
	// -- Draw BackGround
	var tempCanvasRatio = parseInt(localStorage.getItem("canvasRatio")||canvasRatio);
	if(isNaN(tempCanvasRatio)) tempCanvasRatio=20;
	if(tempCanvasRatio<1) tempCanvasRatio=1;
	if(tempCanvasRatio>99) tempCanvasRatio=99;
	canvasRatio = tempCanvasRatio*data.header.resolution/480;
	if(data.header.resolution==960) canvasRatio/=2;
	backCanvases = [];
	var tempCanvasLength = data.songLength/canvasRatio;
	if (tempCanvasLength > 100000) tempCanvasLength = 100000; // Canvas数を制限。全Canvasのwidth合計が100000pxまで(メモリ150MBくらい？)
	for(var i=0; i<=tempCanvasLength; i+=canvas.width){
		backCanvases.push(createElement('canvas', { width: canvas.width, height: canvas.height }));
	}

	if(!isBlackMode){
		if(data.beatTrack.length==0) data.beatTrack.push({ timing:0, value:[4,4] });
		data.beatTrack.forEach(function(beat, idx){
			for(var i=beat.timing; i<(data.beatTrack[idx+1] ? data.beatTrack[idx+1].timing : data.songLength); i+=data.header.resolution/(beat.value[1]/4)){
				var tempCanvas = backCanvases[Math.floor(i/canvasRatio/canvas.width)];
				if (tempCanvas) {
					var context = tempCanvas.getContext('2d');
					context.fillStyle = "#00f";
					context.globalAlpha = 0.1;
					context.fillRect(i/canvasRatio%canvas.width, 0, 1, canvas.height);
				}
			}
			for(var i=beat.timing; i<(data.beatTrack[idx+1] ? data.beatTrack[idx+1].timing : data.songLength); i+=data.header.resolution/(beat.value[1]/4)*beat.value[0]){
				var tempCanvas = backCanvases[Math.floor(i/canvasRatio/canvas.width)];
				if (tempCanvas) {
					var context = tempCanvas.getContext('2d');
					context.fillStyle = "#00f";
					context.globalAlpha = 0.1;
					context.fillRect(i/canvasRatio%canvas.width, 0, 1, canvas.height);
				}
			}
		});
	}
	// -- Draw Notes
	for(var i=data.channels.length-1; i>=0; i--){
		var barWidth = canvasRatio;
		var barHeightDec = canvasNoteHeight-1;
		data.channels[i].notes.forEach(function(note){
			var events = []; // [{timing, pitchBend, expression, modulation}, ...] (timing ascending order)
			sortDrawNotes(events, note, "pitchBend", data.lastNoteOffTiming);
			sortDrawNotes(events, note, "expression", data.lastNoteOffTiming);
			sortDrawNotes(events, note, "modulation", data.lastNoteOffTiming);
			var holdBeforeStop = Number.MAX_SAFE_INTEGER;
			if (note.holdBeforeStop) {
				sortDrawNotes(events, note, "holdBeforeStop", data.lastNoteOffTiming);
				holdBeforeStop = Math.floor(note.holdBeforeStop[0].timing/canvasRatio)*canvasRatio;
			}
			var pitchBend = note.pitchBend[0].value;
			var expression = note.expression[0].value;
			var modulation = note.modulation[0].value;
			var PI_D = Math.PI / 180;
			idx = 1;
			xStop = note.stop>=data.lastNoteOffTiming ? data.lastNoteOffTiming : note.stop;
			for(var x=Math.floor(note.start/canvasRatio)*canvasRatio; x<=xStop;){
				if(note.channel!=9){
					if(idx < events.length){
						barWidth = events[idx].timing-x;
					} else {
						barWidth = xStop-x+1;
					}
				}
				for(var c=0; Math.floor(x/canvasRatio/canvas.width)+c <= Math.floor((x+barWidth)/canvasRatio/canvas.width); c++){
					var tempCanvas = backCanvases[Math.floor(x/canvasRatio/canvas.width)+c];
					if (tempCanvas) {
						var context = tempCanvas.getContext('2d');
						var barX = (x/canvasRatio)%canvas.width-c*canvas.width;
						var barY = 384-(note.pitch+pitchBend)*canvasNoteHeight+canvasBottomMargin-canvasNoteHeight;
						var barW = Math.floor(barWidth/canvasRatio);
						var barH = canvasNoteHeight;
						context.fillStyle = ChannelColor[note.channel];
						context.globalAlpha = (note.velocity*(expression/127));
						if(modulation==0){
							if(note.holdBeforeStop==null || canvasNoteHeight<=2 || x<holdBeforeStop){
								context.fillRect(barX, barY, barW, barH);
							} else {
								context.fillRect(barX, barY, barW, 1);
								context.fillRect(barX, barY+barH-1, barW, 1);
								if (idx>=events.length) {
									context.fillRect(barX+barW-1, barY+1, 1, barH-2);
								}
							}
						} else {
							for(var mx=0; mx<barW; mx++){
								var mAng = -Math.sin(((barX+mx+c*canvas.width))*Math.PI/180*60);
								var mGain = modulation/127;
								if(note.holdBeforeStop==null || x<holdBeforeStop || (idx >= events.length && mx>=barW-1)){
									context.fillRect(barX+mx, barY+(mAng*barH/4)*mGain, 1, barH-(mAng*barH/2)*mGain);
								} else {
									context.fillRect(barX+mx, barY+(mAng*barH/4)*mGain, 1, 1);
									context.fillRect(barX+mx, barY+barH-1-(mAng*barH/4)*mGain, 1, 1);
								}
							}
						}
					}
				}
				if(note.channel==9){
					break;
				} else {
					if(idx < events.length){
						var ev = events[idx];
						if(ev.pitchBend!=null) pitchBend = ev.pitchBend;
						if(ev.expression!=null) expression = ev.expression;
						if(ev.modulation!=null) modulation = ev.modulation;
					}
					x+=barWidth;
					idx++;
				}
			}
		});
	}
	if(pAudio.debug){
		var syoriTimeS3 = performance.now();
		console.log("canvas draw time", syoriTimeS3 - syoriTimeS2);
	}
	// Play
	pAudio.setData(data);
	if(pAudio.debug){
		var syoriTimeE = performance.now();
		console.log("loadFile time", syoriTimeE - syoriTimeS);
	}
	draw(-canvas.width/2);
	if(isFirst){
		var context = canvas.getContext('2d');
		context.globalAlpha = 0.5;
		context.drawImage(stop_icon, Math.floor((canvas.width-376)/2), Math.floor((canvas.height-376)/2));
		context.globalAlpha = 1;
	}
	if(!isFirst) setTimeout(function(){ play(); }, 10);
}
function sortDrawNotes(events, note, noteVariable, lastNoteOffTiming){
	timingOld = -1;
	var idx = events.length-1;
	for(var n=note[noteVariable].length-1; n>=0; n--){
		var v = note[noteVariable][n];
		var t = Math.floor(v.timing/canvasRatio)*canvasRatio;
		if(timingOld==t) continue;
		timingOld = t;
		if(v.timing>lastNoteOffTiming) break;
		var eventObj;
		for(; idx>=0; idx--){
			eventObj = events[idx];
			if(t >= eventObj.timing) break;
		}
		if(eventObj && t==eventObj.timing){
			eventObj[noteVariable] = v.value;
			idx--;
		} else {
			idx++;
			eventObj = {timing:t}
			eventObj[noteVariable] = v.value;
			// events.splice(idx, 0, eventObj); を軽量化
			if(idx == 0) events.unshift(eventObj);
			else if(idx == events.length) events.push(eventObj);
			else events.splice(idx, 0, eventObj);
		}
	}
}

//--------------//
//---- Play ----//
//--------------//

// Trigger Setting
pAudio.trigger.isNoteTrigger = true;
pAudio.trigger.noteOn = function(note){
	polyphonyCnt += 1 + (note.channel==9);
	if(note.channel==9) return;
	currentPlayingNotes.push(note.pitch);
}
pAudio.trigger.noteOff = function(note){
	polyphonyCnt -= 1 + (note.channel==9);
	if(note.channel==9) return;
	currentPlayingNotes.some(function(playNote, idx){
		if(note.pitch==playNote){
			// currentPlayingNotes.splice(idx,1); を軽量化
			if(idx == 0) currentPlayingNotes.shift();
			else if(idx == currentPlayingNotes.length-1) currentPlayingNotes.pop();
			else currentPlayingNotes.splice(idx,1);
			return true;
		}
	});
}

// Play
function play(){
	if(isFirst){
		isFirst = false;
		// setValueAtTimeで引数がマイナスになりエラーとなるので「-pAudio.states.startTime」を指定
		pAudio.createBaseNote({startTime:-pAudio.states.startTime,stopTime:-pAudio.states.startTime+1,velocity:0.00000001});
	}
	polyphonyCnt = 0;
	currentPlayingNotes = [];
	pAudio.play();
	document.getElementById("actionPlay").style.backgroundImage = 'url("./img/icon_stop.png")';
	if(isFirst) isFirst = false;
}

// Stop
function stop(isSongLooping){
	pAudio.stop(isSongLooping);
	document.getElementById("actionPlay").style.backgroundImage = 'url("./img/icon_play.png")';
	var context = canvas.getContext('2d');
	context.globalAlpha = 0.5;
	context.drawImage(stop_icon, Math.floor((canvas.width-376)/2), Math.floor((canvas.height-376)/2));
	context.globalAlpha = 1;
}

// Canvas Handlings
canvas.addEventListener('click', function(e){
	if(!data) return;
	if((e.clientY-canvas.offsetTop+window.scrollY)<canvas.offsetHeight*0.9){
		if(pAudio.states.isPlaying){
			if(isNiceMode!=1){
				isDisplayNice = isDisplayNice ? false : true;
			} else {
				if(!currentLoadFile) return;
				var p = Math.floor(pAudio.getTiming((pAudio.states.isPlaying?pAudio.context.currentTime:pAudio.states.stopTime) - pAudio.states.startTime)/canvasRatio -canvas.width/2);
				var x = parseInt(((e.clientX/canvas.offsetWidth)*canvas.width-canvas.offsetLeft + Math.floor((p+canvas.width/2)/canvas.width)*canvas.width)*canvasRatio);
				var y = parseInt((e.clientY-canvas.offsetTop+window.scrollY - canvas.height*(1-canvasNoteHeight/4) - canvasBottomMargin)/canvasNoteHeight*4);
				var xhr = new XMLHttpRequest();
				xhr.open("GET", "./cmd/CreateFavorite.php?file="+currentLoadFile+"&x="+x+"&y="+y);
				xhr.responseType = "text";
				xhr.send(null);
				favoriteList.push([x, y]);
				document.getElementById("settingNiceMode").checked = false;
				isNiceMode = 2;
				if(!isPlayerCard){
					if(!favoriteSongs[currentLoadFile])
						favoriteSongs[currentLoadFile] =
							{
								fav: 0,
								user: document.getElementById("info_user").textContent,
								title: document.getElementById("info_title").textContent,
								date: document.getElementById("info_date").textContent,
								file: currentLoadFile
							};
					favoriteSongs[currentLoadFile].fav +=1;
				}
				localStorage.setItem("favoriteSongs", JSON.stringify(favoriteSongs));
				setTimeout(function(){
					isNiceMode = false;
					document.getElementById("settingNiceMode").checked = false;
					document.getElementById("settingNiceMode").style.filter = "invert(40%)";
					document.getElementById("settingNiceMode").style.webkitFilter = ele.style.filter;
				}, 500)
			}
		} else {
			play();
		}
	} else {
		var posX = (e.clientX-canvas.offsetLeft)/canvas.offsetWidth;
		var bgmLength = pAudio.getTime(Number.MAX_SAFE_INTEGER);
		var offset = posX * bgmLength;
		if(offset > bgmLength) offset = bgmLength;
		else if(offset < 0) offset = 0;
		if(pAudio.states.isPlaying) pAudio.stop();
		pAudio.initStatus(false, true);
		pAudio.setStartTime(offset);
		play();
	}
});

// Canvas Handlings
canvas.addEventListener('mousemove', function(e){
	if(isNiceMode){
		if(!pAudio || !pAudio.context) return;
		var p = Math.floor(pAudio.getTiming((pAudio.states.isPlaying?pAudio.context.currentTime:pAudio.states.stopTime) - pAudio.states.startTime)/canvasRatio -canvas.width/2);
		niceX = parseInt(((e.clientX/canvas.offsetWidth)*canvas.width-canvas.offsetLeft + Math.floor((p+canvas.width/2)/canvas.width)*canvas.width)*canvasRatio);
		niceY = parseInt((e.clientY-canvas.offsetTop+window.scrollY - canvas.height*(1-canvasNoteHeight/4) - canvasBottomMargin)/canvasNoteHeight*4);
	}
});

// Buttons
document.getElementById("actionPlay").addEventListener("click", function(e){
	if(!data){
		 setSong("QHYWJGRC.mid");
	} else {
		pAudio.states.isPlaying ? stop() : play();
	}
});

document.getElementById("actionPre").addEventListener("click", function(e){
	if(!data) return;
	var rand = (randBtn = document.getElementById("playTypeRandom")) && randBtn.checked;
	if(!isPlayerCard
		&& ((currentView != 3 && currentPlayListIndex>0)
			|| (currentView == 3 && (rand || localSongList.indexOf(currentLoadFile)-1 >= 0)))
		&& pAudio.context.currentTime-pAudio.states.startTime<1
	){
		if(currentView == 3){
			var list = rand ? localSongRandomList : localSongList;
			if(rand){
				setLocalSong({title: list[(list.indexOf(currentLoadFile)-1+list.length)%list.length]});
			} else {
				setLocalSong({title: list[list.indexOf(currentLoadFile)-1]});
			}
		} else {
			currentPlayListIndex--;
			setSong(playList[currentPlayListIndex], true);
		}
	} else {
		pAudio.initStatus();
		play();
	}
});

if(!isPlayerCard){
	document.getElementById("actionPost").addEventListener("click", function(e){
		if(!data) return;
		if(currentPlayListIndex+1<playList.length){
			setSong(playList[currentPlayListIndex+1]);
		} else {
			if(document.getElementById("playTypeRandom").checked){
				if(currentView == 0){
					setSongRandom();
				} else {
					var list = [latestSongList, favoriteSongList, tabSongList, localSongRandomList][currentView];
					if(currentView == 3){
						setLocalSong({title: list[(list.indexOf(currentLoadFile)+1)%list.length]});
					} else {
						setSong(list[Math.floor(Math.random()*list.length)]);
					}
				}
			} else if(currentLoadFile){
				if(currentView == 0){
					if(latestSongList.length-5<=latestSongList.indexOf(currentLoadFile)+1){
						loadSongList();
					}
				}
				var list = [latestSongList, favoriteSongList, tabSongList, localSongList][currentView];
				if(currentView == 3){
					setLocalSong({title: list[list.indexOf(currentLoadFile)+1]});
				} else {
					if(list.length>list.indexOf(currentLoadFile)+1 && list.indexOf(currentLoadFile)!=-1)
						setSong(list[list.indexOf(currentLoadFile)+1]);
					else
						setSongRandom();
				}
			} else {
				stop();
				pAudio.initStatus();
			}
		}
	});

	["settingDisplayLogo", "playTypeRandom", "playTypeLoop"].forEach(function(t){
		document.getElementById(t).addEventListener("click", function(e){
			var ele = e.target
			if(ele.checked = ele.checked ? false : true)
				ele.style.filter = "invert(0%)";
			else
				ele.style.filter = "invert(40%)";
			ele.style.webkitFilter = ele.style.filter;
		});
	});

	document.getElementById("settingVolume").addEventListener("click", function(e){
		pAudio.setMasterVolume((((pAudio.getMasterVolume()+0.5)*10)%15)/10);
	});

}

document.getElementById("settingNiceMode").addEventListener("click", function(e){
	var ele = e.target
	if(ele.checked = ele.checked ? false : true)
		ele.style.filter = "invert(0%)";
	else
		ele.style.filter = "invert(40%)";
	ele.style.webkitFilter = ele.style.filter;
	isNiceMode = e.target.checked;
	if(isNiceMode) isDisplayNice = true;
});

function setSongRandom(){
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200){
			setSong(JSON.parse(this.response).file);
		}
	}
	xhr.open("GET", "./cmd/GetSongRandom.php");
	xhr.responseType = "text";
	xhr.send(null);
}

// Draw PianoRoll Animation
if(!window.requestAnimationFrame || fps!=0){
	if(fps<=0) fps=60;
	setInterval(function(){
		if(pAudio.states.isPlaying==false) return;
		draw(Math.floor(pAudio.getTiming(pAudio.context.currentTime-pAudio.states.startTime)/canvasRatio - canvas.width/2));
	}, 1000/fps);
} else {
	(function render(){
		if(pAudio.states.isPlaying==false) {
		} else if(pAudio.getTiming(pAudio.context.currentTime-pAudio.states.startTime)/canvasRatio < data.songLength/canvasRatio-1){
			draw(Math.floor(pAudio.getTiming(pAudio.context.currentTime-pAudio.states.startTime)/canvasRatio - canvas.width/2));
		}
		window.requestAnimationFrame(render);
	})();
}

pAudio.onSongEndListener = function(){
	if(isPlayerCard) return;
	if(document.getElementById("playTypeLoop").checked){
		stop(true);
		pAudio.initStatus(true);
		if(pAudio.settings.isCC111 && pAudio.cc111Time != -1){
			pAudio.setStartTime(pAudio.cc111Time);
		}
		play(true);
	} else if(document.getElementById("playTypeRandom").checked){
		if(currentView == 0){
			setSongRandom();
		} else {
			var list = [latestSongList, favoriteSongList, tabSongList, localSongList][currentView];
			var curloadFileIdx = list.indexOf(currentLoadFile);
			if(currentView == 3){
				if(list.length>curloadFileIdx+1){
					setLocalSong({title: list[curloadFileIdx+1]});
				}
			} else {
				setSong(list[Math.floor(Math.random()*list.length)]);
			}
		}
	} else if(currentLoadFile){
		if(currentView == 0){
			if(latestSongList.length-5<=latestSongList.indexOf(currentLoadFile)+1){
				loadSongList();
			}
		}
		var list = [latestSongList, favoriteSongList, tabSongList, localSongList][currentView];
		var curloadFileIdx = list.indexOf(currentLoadFile);
		if(currentView == 3){
			if(list.length>curloadFileIdx+1){
				setLocalSong({title: list[curloadFileIdx+1]});
			}
		} else {
			if(list.length>curloadFileIdx+1 && curloadFileIdx!=-1){
				if(list.length>curloadFileIdx+1){
					setSong(list[curloadFileIdx+1]);
				}
			} else {
				setSongRandom();
			}
		}
	} else {
		stop();
		pAudio.initStatus();
	}
}

// Draw Main
var monitorFps = 0;
var monitorFpsCnt = 0;
var monitorFpsTime = performance.now();
var monitorFpsInter = 1000;
var noteCntMax = 0;
var noteCntMaxTime = performance.now();
var noteCntMaxTimeout = 3000;
var polyCntMax = 0;
var polyCntMaxTime = performance.now();
var polyCntMaxTimeout = 3000;
function draw(x){
	var context = canvas.getContext('2d');
	context.globalAlpha = 1;
	if(isBlackMode)
		context.fillStyle = "#000";
	else
		context.fillStyle = "#fff";
	context.fillRect(0, 0, canvas.width, canvas.height);

	if(!isBlackMode)
		context.drawImage(backPianoRoll, 0, 0, canvas.width, canvas.height);

	var canvasW = backCanvases[0] ? backCanvases[0].width : canvas.width;
	if(!isNiceMode){
		// 常時スクロール
		var addX = -mod(x, canvasW);
		for(var i=0; i<5; i++){
			var canvasesIdx = Math.floor(x/canvasW)+i;
			var backCanvas = backCanvases[canvasesIdx];
			if(backCanvas){
				context.drawImage(backCanvas, addX, 0);
			}
			addX += canvasW;
			if(addX>canvas.width) break;
		}
		context.fillStyle = "#888";
		context.fillRect(Math.floor(canvas.width/2), 0, 1, canvas.height);
	} else {
		// ページ切り替わり
		var subW = canvas.width - canvasW;
		var canvasesBaseIdx = Math.floor((x+Math.ceil(canvas.width/2))/(canvasW+subW));
		var canvasesSubIdx = Math.floor((subW*canvasesBaseIdx)/(canvasW));
		var addX = -(mod(subW*canvasesBaseIdx, (canvasW)));
		for(var i=0; i<5; i++){
			var canvasesIdx = canvasesBaseIdx+canvasesSubIdx+i;
			var backCanvas = backCanvases[canvasesIdx];
			if(backCanvas){
				context.drawImage(backCanvas, addX, 0);
			}
			addX += canvasW;
			if(addX>canvas.width) break;
		}
		context.fillStyle = "#888";
		context.fillRect(Math.floor((x+canvas.width/2)%(canvasW+subW)), 0, 1, canvas.height);
	}

	//
	var leftShift = -45;

	// Draw Chord
	if(!isBlackMode){
		var def = [0,7,2,9,4,11,6,1,8,3,10,5];
		var rootNote = 127;
		var currentPlayingNotesMod = currentPlayingNotes.map(function(note){
			if(note<rootNote) rootNote = note;
			return note%12;
		}).filter(function(note, idx, arr){
			return arr.indexOf(note) == idx
		}).sort(function(a,b){
			if( a < b ) return -1;
			if( a > b ) return 1;
			return 0;
		});
		var currentPlayingNotesMod2 = currentPlayingNotesMod.map(function(note){
			return def[note];
		}).sort(function(a,b){
			if( a < b ) return -1;
			if( a > b ) return 1;
			return 0;
		});
		function returnPoint(idx){
			return {x:100+Math.cos(2*Math.PI/12*idx-Math.PI/2)*40+leftShift, y:(canvas.height-84)+Math.sin(2*Math.PI/12*idx-Math.PI/2)*40};
		}
		// 背景描画
		context.globalAlpha = 0.7;
		context.fillStyle = "#fff";
		context.beginPath();
		context.moveTo(returnPoint(0).x, returnPoint(0).y);
		for(var i=1; i<12; i++) context.lineTo(returnPoint(i).x, returnPoint(i).y);
		context.closePath();
		context.fill();
		//
		context.globalAlpha = 0.4;
		context.fillStyle = "#888";
		context.beginPath();
		var isFirst = true;
		for(var i=0; i<currentPlayingNotesMod2.length; i++){
			var u=currentPlayingNotesMod2[i];
			if(isFirst){
				context.moveTo(returnPoint(u).x, returnPoint(u).y);
				isFirst = false;
			} else {
				context.lineTo(returnPoint(u).x, returnPoint(u).y);
			}
		}
		context.closePath();
		context.fill();
		// 音階描画
		context.globalAlpha = 1;
		context.fillStyle = "#888";
		for(var i=0; i<12; i++){
			if(rootNote!=127 && i==def[rootNote%12]) context.fillStyle = "#4d4";
			context.fillText(["C ","G ","D ","A ","E ","B ","F#","C#","G#","D#","A#","F "][i], returnPoint(i).x-5, returnPoint(i).y+2.5);
			if(i==def[rootNote%12]) context.fillStyle = "#888";
		}
		// Draw chordname
		for(var i=0; i<12; i++){
			var c = "";
			Object.keys(C_CHORDS).forEach(function(code){
				var _list = currentPlayingNotesMod.filter(function(note, idx, arr){
					return C_CHORDS[code].map(function(n){ return (n+i)%12}).indexOf(note)!=-1
				});
				if(_list.length == C_CHORDS[code].length)
					c = CHORDS[i]+code.slice(1);
			});
			if(i==rootNote%12){
				context.fillStyle = "#000";
				context.fillText(c, 100+leftShift, canvas.height-84);
			}
		}

		// tempo
		context.fillStyle = "#000";
		var currentTiming = Math.floor(pAudio.getTiming(( pAudio.context ? pAudio.context.currentTime : 0 )-pAudio.states.startTime));
		var bpm = 120;
		pAudio.tempoTrack.some(function(tempo){
			if(tempo.timing>currentTiming)
				return true;
			bpm = Math.floor(tempo.value+0.5);
		});
		context.fillText("BPM "+bpm, 50+leftShift, canvas.height-27);

		// beat
		var beat = "4/4";
		data.beatTrack.some(function(b){
			if(b.timing>currentTiming)
				return true;
			beat = b.value.join("/");
		});
		context.fillText("BEAT "+beat, 50+leftShift, canvas.height-12);

		// bar


		// time
		var time = ( pAudio.context ? pAudio.context.currentTime : 0 )-pAudio.states.startTime;
		var timeLength = pAudio.getTime(data.songLength);
		context.fillText("TIME "+Math.floor(time/60)+" : "+(Math.floor(time%60)<10?"0":"")+Math.floor(time%60)
			+"  /  "+Math.floor(timeLength/60)+" : "+(Math.floor(timeLength%60)<10?"0":"")+Math.floor(timeLength%60), 120+leftShift, canvas.height-12);

		//seek
		context.fillStyle = "#f77";
		context.globalAlpha = 0.4;
		context.fillRect(0, canvas.height-5, canvas.width, 5);
		context.fillStyle = "#f00";
		context.globalAlpha = 0.4;
		context.fillRect(0, canvas.height-5, canvas.width*(((pAudio.states.isPlaying ? pAudio.context.currentTime : pAudio.states.stopTime)-pAudio.states.startTime)/pAudio.getTime(data.songLength)), 5);
		context.globalAlpha = 1;
		context.fillStyle = "#f77";

		//favorite
		if(isDisplayNice){
			context.textAlign = "center"; // テキスト左右中央寄せ
			context.textBaseline = "middle"; // テキスト上下中央寄せ
			favoriteList.forEach(function(fav){
				if(!fav || fav.length==0) return;
				if(!isNiceMode){
					if(fav[0]/canvasRatio-x<-32 || canvas.width+32<fav[0]/canvasRatio-x) return;
					context.fillText("👍", fav[0]/canvasRatio-x, canvas.height*(1-canvasNoteHeight/4)+fav[1]*canvasNoteHeight/4+canvasBottomMargin);
				} else {
					if(Math.floor((x+canvas.width/2)/canvas.width) != Math.floor((fav[0]/canvasRatio)/canvas.width)) return;
					context.fillText("👍", (fav[0]/canvasRatio)%canvas.width, canvas.height*(1-canvasNoteHeight/4)+fav[1]*canvasNoteHeight/4+canvasBottomMargin);
				}
			});
			context.textAlign = "start";
			context.textBaseline = "alphabetic";
		}
		if(isNiceMode){
			context.fillText("ピアノロールをクリックするといいね👍を置くことができます", canvas.width<=canvas.height+200 ? 5 : 230+(canvas.width-608), canvas.width<=canvas.height+200 ? 10 : 372);
			context.textAlign = "center"; // テキスト左右中央寄せ
			context.textBaseline = "middle"; // テキスト上下中央寄せ
			var favX = typeof niceX!=="undefined" && niceX;
			var favY = typeof niceY!=="undefined" && niceY;
			context.globalAlpha = 0.5;
			context.fillStyle = "#f77";
			context.fillText("👍", (favX/canvasRatio)%canvas.width, canvas.height*(1-canvasNoteHeight/4)+favY*canvasNoteHeight/4+canvasBottomMargin);
			context.globalAlpha = 1;
			context.textAlign = "start";
			context.textBaseline = "alphabetic";
		}

		// Retro Mode
		if(isRetroMode && !pAudio.settings.isWebMIDI){
			context.fillStyle = "#00f";
			context.fillText("RETRO MODE ("+retroModePoly+" + "+retroModePercPoly+")", 120+leftShift, canvas.height-27);
			if(!pAudio.states.isPlaying)
				context.fillText("※レトロモードが有効です。同時発音数が制限されます", 120+leftShift, canvas.height-43);
		}

		// logo
		if(!isPlayerCard && document.getElementById("settingDisplayLogo").checked){
			context.globalAlpha = 0.8;
			context.drawImage(logo_icon, Math.floor(canvas.width-80), Math.floor(canvas.height-22));
			context.globalAlpha = 1;
		}
	}

	if(pAudio.debug){
		// monitor FPS
		monitorFpsCnt++;
		var nowTime = performance.now();
		var subTime = nowTime-monitorFpsTime;
		if(subTime>=monitorFpsInter){
			monitorFps = monitorFpsCnt * (1000/subTime);
			monitorFpsTime = nowTime;
			monitorFpsCnt = 0;
		}
		var tx1 = 50, tx2 = 180, ty = 27, tya = 15;
		context.fillStyle = isBlackMode ? "#fff" : "#000";
		context.fillText("FPS "+Math.floor(monitorFps)+"."+Math.floor(monitorFps*10)%10, tx1+leftShift, ty);
		ty += tya;
		// Reserved Note Cnt, Max
		var noteCnt = pAudio.states.stopFuncs.length;
		if(noteCntMax<=noteCnt){
			noteCntMax = noteCnt;
			noteCntMaxTime = nowTime;
		}
		if(nowTime-noteCntMaxTime>=noteCntMaxTimeout){
			noteCntMax = 0;
			noteCntMaxTime = nowTime;
		}
		context.fillText("Reserved Func Cnt", tx1+leftShift, ty);
		context.fillText(noteCnt, tx2+leftShift, ty);
		ty += tya;

		context.fillText("Reserved Func Max", tx1+leftShift, ty);
		context.fillText(noteCntMax, tx2+leftShift, ty);
		ty += tya;

		// Polyphony Cnt
		var polyCnt = polyphonyCnt;
		if(polyCntMax<=polyCnt){
			polyCntMax = polyCnt;
			polyCntMaxTime = nowTime;
		}
		if(nowTime-polyCntMaxTime>=polyCntMaxTimeout){
			polyCntMax = 0;
			polyCntMaxTime = nowTime;
		}
		context.fillText("Polyphony Cnt", tx1+leftShift, ty);
		context.fillText(polyCnt, tx2+leftShift, ty);
		ty += tya;
		context.fillText("Polyphony Max", tx1+leftShift, ty);
		context.fillText(polyCntMax, tx2+leftShift, ty);
		ty += tya;

		context.fillText("performance.now Time", tx1+leftShift, ty);
		context.fillText(performance.now(), tx2+leftShift, ty);
		ty += tya;

		context.fillText("Audio Current Time", tx1+leftShift, ty);
		context.fillText(time, tx2+leftShift, ty);
		ty += tya;

		context.fillText("Audio Base Latency", tx1+leftShift, ty);
		if(pAudio.context != null && pAudio.context.baseLatency != null){
			context.fillText(pAudio.context.baseLatency, tx2+leftShift, ty);
		}
		ty += tya;

		context.fillText("updateIntervalTime", tx1+leftShift, ty);
		context.fillText(pAudio.states.updateIntervalTime, tx2+leftShift, ty);
		ty += tya;

		context.fillText("updateBufTime", tx1+leftShift, ty);
		context.fillText(pAudio.states.updateBufTime, tx2+leftShift, ty);
		ty += tya;

		context.fillText("updateBufMaxTime", tx1+leftShift, ty);
		context.fillText(pAudio.states.updateBufMaxTime, tx2+leftShift, ty);
		ty += tya;

		context.fillText("latencyTime", tx1+leftShift, ty);
		if(pAudio.states.latencyTime != null){
			context.fillText(pAudio.states.latencyTime, tx2+leftShift, ty);
		}
		ty += tya;

		context.fillText("latencyLimitTime", tx1+leftShift, ty);
		if(pAudio.states.latencyLimitTime != null){
			context.fillText(pAudio.states.latencyLimitTime, tx2+leftShift, ty);
		}
		ty += tya;
	}
}

function mod(a, b){return(a*b<0)*b+a%b}

function initChannels(){
	for(i in pAudio.channels)
		pAudio.channels[i] = [0,0,1];
}

// Wrap createElement Function
function createElement(tagName, options){
	var options = options;
	var tag = document.createElement(tagName);
	Object.keys(options).forEach(function(key){
		if(key=='appendTo'){
			options[key].appendChild(tag);
			return;
		} else if(key=='insertBeforeTo'){
			options[key][0].insertBefore(tag, options[key][1]);
			return;
		} else if(key=='style'){
			Object.keys(options[key]).forEach(function(keyStyle){
				tag.style[keyStyle] = options[key][keyStyle];
			});
			return;
		}
		tag[key] = options[key];
	});
	return tag;
}
